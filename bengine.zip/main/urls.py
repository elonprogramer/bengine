"""Типу хаткес підключення юрл до сторінок views.py"""

from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='home'),
    path('aboute-us', views.aboute, name='aboute'),
    path('create', views.create, name='create'),
]